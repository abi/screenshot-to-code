# Run tests

poetry run pytest
